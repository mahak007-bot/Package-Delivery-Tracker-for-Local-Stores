package com.example.tracker.service;

import com.example.tracker.model.Store;
import com.example.tracker.model.DeliveryPerson;
import com.example.tracker.model.Package;
import com.example.tracker.model.PackageStatus;
import com.example.tracker.util.Validator;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DeliveryService {
    private List<Store> stores;
    private List<DeliveryPerson> deliveryPersons;
    private List<Package> packages;

    public DeliveryService() {
        this.stores = new ArrayList<>();
        this.deliveryPersons = new ArrayList<>();
        this.packages = new ArrayList<>();
        seedData();
    }

    private void seedData() {
        addStore("S001", "Central Mart", "123 Main St");
        addStore("S002", "Quick Picks", "456 Oak Ave");
        addDeliveryPerson("DP001", "John Doe", "555-1234");
        addDeliveryPerson("DP002", "Jane Smith", "555-5678");
        addPackage("PKG001", "Sender A", "Recipient X", "789 Pine Ln", "S001");
        addPackage("PKG002", "Sender B", "Recipient Y", "101 Elm Dr", "S002");
    }

    public void addStore(String storeId, String name, String address) {
        if (!Validator.isNotNullOrEmpty(storeId) || !Validator.isNotNullOrEmpty(name) || !Validator.isNotNullOrEmpty(address)) {
            System.out.println("Error: All store fields must be provided.");
            return;
        }
        if (getStoreById(storeId) != null) {
            System.out.println("Error: Store with ID '" + storeId + "' already exists.");
            return;
        }
        stores.add(new Store(storeId, name, address));
        System.out.println("Store '" + name + "' added successfully.");
    }

    public void addDeliveryPerson(String personId, String name, String contactNumber) {
        if (!Validator.isNotNullOrEmpty(personId) || !Validator.isNotNullOrEmpty(name) || !Validator.isNotNullOrEmpty(contactNumber)) {
            System.out.println("Error: All delivery person fields must be provided.");
            return;
        }
        if (!Validator.isValidContactNumber(contactNumber)) {
            System.out.println("Error: Invalid contact number format.");
            return;
        }
        if (getDeliveryPersonById(personId) != null) {
            System.out.println("Error: Delivery person with ID '" + personId + "' already exists.");
            return;
        }
        deliveryPersons.add(new DeliveryPerson(personId, name, contactNumber));
        System.out.println("Delivery person '" + name + "' added successfully.");
    }

    public void addPackage(String trackingId, String sender, String recipient, String destination, String storeId) {
        if (!Validator.isNotNullOrEmpty(trackingId) || !Validator.isNotNullOrEmpty(sender) || !Validator.isNotNullOrEmpty(recipient) || !Validator.isNotNullOrEmpty(destination) || !Validator.isNotNullOrEmpty(storeId)) {
            System.out.println("Error: All package fields must be provided.");
            return;
        }
        if (!Validator.isValidTrackingId(trackingId)) {
            System.out.println("Error: Invalid Tracking ID format (e.g., must be 6-10 alphanumeric characters).");
            return;
        }
        if (getPackageByTrackingId(trackingId) != null) {
            System.out.println("Error: Package with Tracking ID '" + trackingId + "' already exists.");
            return;
        }
        Store associatedStore = getStoreById(storeId);
        if (associatedStore == null) {
            System.out.println("Error: Associated Store with ID '" + storeId + "' not found.");
            return;
        }
        packages.add(new Package(trackingId, sender, recipient, destination, associatedStore));
        System.out.println("Package '" + trackingId + "' added successfully for store '" + associatedStore.getName() + "'.");
    }

    public void assignPackage(String trackingId, String personId) {
        Package pkg = getPackageByTrackingId(trackingId);
        DeliveryPerson person = getDeliveryPersonById(personId);

        if (pkg == null) {
            System.out.println("Error: Package with ID '" + trackingId + "' not found.");
            return;
        }
        if (person == null) {
            System.out.println("Error: Delivery person with ID '" + personId + "' not found.");
            return;
        }
        if (pkg.getAssignedTo() != null) {
            System.out.println("Error: Package '" + trackingId + "' is already assigned to " + pkg.getAssignedTo().getName() + ".");
            return;
        }
        if (pkg.getStatus() != PackageStatus.PENDING) {
            System.out.println("Error: Package '" + trackingId + "' cannot be assigned. Current status is " + pkg.getStatus() + ".");
            return;
        }

        pkg.setAssignedTo(person);
        pkg.setStatus(PackageStatus.IN_TRANSIT);
        System.out.println("Package '" + trackingId + "' assigned to '" + person.getName() + "' and status set to IN_TRANSIT.");
    }

    public void updatePackageStatus(String trackingId, String newStatusString) {
        Package pkg = getPackageByTrackingId(trackingId);
        if (pkg == null) {
            System.out.println("Error: Package with ID '" + trackingId + "' not found.");
            return;
        }

        PackageStatus newStatus;
        try {
            newStatus = PackageStatus.valueOf(newStatusString.toUpperCase());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Invalid status. Valid options are: PENDING, IN_TRANSIT, DELIVERED, CANCELED.");
            return;
        }

        if (pkg.getStatus() == PackageStatus.DELIVERED || pkg.getStatus() == PackageStatus.CANCELED) {
            System.out.println("Error: Cannot change status of a delivered or canceled package.");
            return;
        }

        if (newStatus == PackageStatus.DELIVERED && pkg.getStatus() != PackageStatus.IN_TRANSIT) {
            System.out.println("Error: Package must be IN_TRANSIT to be marked DELIVERED.");
            return;
        }

        if (newStatus == PackageStatus.IN_TRANSIT && pkg.getAssignedTo() == null) {
            System.out.println("Error: Package must be assigned to a delivery person to be IN_TRANSIT.");
            return;
        }
        
        if (newStatus == PackageStatus.PENDING && pkg.getStatus() != PackageStatus.PENDING) {
            System.out.println("Error: Cannot revert package status to PENDING once it has moved.");
            return;
        }

        pkg.setStatus(newStatus);
        if (newStatus == PackageStatus.DELIVERED) {
            pkg.setDeliveryDate(LocalDate.now());
        }
        System.out.println("Package '" + trackingId + "' status updated to " + newStatus + ".");
    }

    public Store getStoreById(String storeId) {
        return stores.stream()
                     .filter(s -> s.getStoreId().equalsIgnoreCase(storeId))
                     .findFirst()
                     .orElse(null);
    }

    public DeliveryPerson getDeliveryPersonById(String personId) {
        return deliveryPersons.stream()
                              .filter(dp -> dp.getPersonId().equalsIgnoreCase(personId))
                              .findFirst()
                              .orElse(null);
    }

    public Package getPackageByTrackingId(String trackingId) {
        return packages.stream()
                       .filter(p -> p.getTrackingId().equalsIgnoreCase(trackingId))
                       .findFirst()
                       .orElse(null);
    }

    public void displayAllStores() {
        if (stores.isEmpty()) {
            System.out.println("No stores registered.");
            return;
        }
        System.out.println("\n--- All Stores ---");
        stores.forEach(System.out::println);
        System.out.println("-----------------");
    }

    public void displayAllDeliveryPersons() {
        if (deliveryPersons.isEmpty()) {
            System.out.println("No delivery persons registered.");
            return;
        }
        System.out.println("\n--- All Delivery Persons ---");
        deliveryPersons.forEach(System.out::println);
        System.out.println("---------------------------");
    }

    public void displayAllPackages() {
        if (packages.isEmpty()) {
            System.out.println("No packages in the system.");
            return;
        }
        System.out.println("\n--- All Packages ---");
        packages.forEach(System.out::println);
        System.out.println("--------------------");
    }

    public void displayPackagesByStatus(String statusString) {
        PackageStatus status;
        try {
            status = PackageStatus.valueOf(statusString.toUpperCase());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Invalid status. Valid options are: PENDING, IN_TRANSIT, DELIVERED, CANCELED.");
            return;
        }

        List<Package> filteredPackages = packages.stream()
                                                 .filter(pkg -> pkg.getStatus() == status)
                                                 .collect(Collectors.toList());
        if (filteredPackages.isEmpty()) {
            System.out.println("No " + status.toString().toLowerCase() + " packages found.");
            return;
        }
        System.out.println("\n--- " + status.toString() + " Packages ---");
        filteredPackages.forEach(System.out::println);
        System.out.println("----------------------------");
    }

    public void displayPackagesByDeliveryPerson(String personId) {
        DeliveryPerson person = getDeliveryPersonById(personId);
        if (person == null) {
            System.out.println("Error: Delivery person with ID '" + personId + "' not found.");
            return;
        }

        List<Package> assignedPackages = packages.stream()
                                                 .filter(pkg -> pkg.getAssignedTo() != null && pkg.getAssignedTo().getPersonId().equalsIgnoreCase(personId))
                                                 .collect(Collectors.toList());
        if (assignedPackages.isEmpty()) {
            System.out.println("No packages assigned to '" + person.getName() + "'.");
            return;
        }
        System.out.println("\n--- Packages assigned to " + person.getName() + " ---");
        assignedPackages.forEach(System.out::println);
        System.out.println("------------------------------------------");
    }

    public void displayPackagesByStore(String storeId) {
        Store store = getStoreById(storeId);
        if (store == null) {
            System.out.println("Error: Store with ID '" + storeId + "' not found.");
            return;
        }

        List<Package> storePackages = packages.stream()
                                              .filter(pkg -> pkg.getAssociatedStore().getStoreId().equalsIgnoreCase(storeId))
                                              .collect(Collectors.toList());
        if (storePackages.isEmpty()) {
            System.out.println("No packages associated with store '" + store.getName() + "'.");
            return;
        }
        System.out.println("\n--- Packages from " + store.getName() + " ---");
        storePackages.forEach(System.out::println);
        System.out.println("---------------------------------");
    }

    public void searchPackageByTrackingId(String trackingId) {
        if (!Validator.isNotNullOrEmpty(trackingId)) {
            System.out.println("Error: Tracking ID cannot be empty.");
            return;
        }
        Package foundPackage = getPackageByTrackingId(trackingId);
        if (foundPackage == null) {
            System.out.println("No package found with Tracking ID '" + trackingId + "'.");
        } else {
            System.out.println("\n--- Search Result for '" + trackingId + "' ---");
            System.out.println(foundPackage);
            System.out.println("-----------------------------------");
        }
    }
}