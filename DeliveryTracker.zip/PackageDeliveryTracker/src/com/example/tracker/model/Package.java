package com.example.tracker.model;

import java.time.LocalDate;

public class Package {
    private String trackingId;
    private String senderName;
    private String recipientName;
    private String destinationAddress;
    private Store associatedStore;
    private DeliveryPerson assignedTo;
    private PackageStatus status;
    private LocalDate creationDate;
    private LocalDate deliveryDate;

    public Package(String trackingId, String senderName, String recipientName, String destinationAddress, Store associatedStore) {
        this.trackingId = trackingId;
        this.senderName = senderName;
        this.recipientName = recipientName;
        this.destinationAddress = destinationAddress;
        this.associatedStore = associatedStore;
        this.assignedTo = null;
        this.status = PackageStatus.PENDING;
        this.creationDate = LocalDate.now();
        this.deliveryDate = null;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public String getSenderName() {
        return senderName;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public Store getAssociatedStore() {
        return associatedStore;
    }

    public DeliveryPerson getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(DeliveryPerson assignedTo) {
        this.assignedTo = assignedTo;
    }

    public PackageStatus getStatus() {
        return status;
    }

    public void setStatus(PackageStatus status) {
        this.status = status;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public LocalDate getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(LocalDate deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    @Override
    public String toString() {
        String assignedInfo = (assignedTo != null) ? ", Assigned To: " + assignedTo.getName() : ", Unassigned";
        String deliveryInfo = (deliveryDate != null) ? ", Delivered On: " + deliveryDate : "";
        return "Tracking ID: " + trackingId + ", Sender: " + senderName + ", Recipient: " + recipientName +
               ", Destination: " + destinationAddress + ", Store: " + associatedStore.getName() +
               ", Status: " + status + ", Created: " + creationDate + assignedInfo + deliveryInfo;
    }
}