package com.example.tracker.model;

public class Store {
    private String storeId;
    private String name;
    private String address;

    public Store(String storeId, String name, String address) {
        this.storeId = storeId;
        this.name = name;
        this.address = address;
    }

    public String getStoreId() {
        return storeId;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return "Store ID: " + storeId + ", Name: " + name + ", Address: " + address;
    }
}