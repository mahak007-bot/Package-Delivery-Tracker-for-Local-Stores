package com.example.tracker.model;

public enum PackageStatus {
    PENDING,
    IN_TRANSIT,
    DELIVERED,
    CANCELED
}