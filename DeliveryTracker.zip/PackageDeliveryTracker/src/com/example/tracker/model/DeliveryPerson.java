package com.example.tracker.model;

public class DeliveryPerson {
    private String personId;
    private String name;
    private String contactNumber;

    public DeliveryPerson(String personId, String name, String contactNumber) {
        this.personId = personId;
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getPersonId() {
        return personId;
    }

    public String getName() {
        return name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    @Override
    public String toString() {
        return "Delivery Person ID: " + personId + ", Name: " + name + ", Contact: " + contactNumber;
    }
}