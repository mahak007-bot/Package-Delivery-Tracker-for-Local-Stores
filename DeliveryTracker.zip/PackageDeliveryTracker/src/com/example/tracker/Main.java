package com.example.tracker;

import com.example.tracker.service.DeliveryService;
import com.example.tracker.util.InputHandler;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InputHandler inputHandler = new InputHandler(scanner);
        DeliveryService deliveryService = new DeliveryService();

        System.out.println("Welcome to the Console Package Delivery Tracker!");

        while (true) {
            displayMenu();
            int choice = inputHandler.getIntegerInput("Enter your choice: ");

            switch (choice) {
                case 1: // Add Store
                    String storeId = inputHandler.getStringInput("Enter Store ID: ");
                    String storeName = inputHandler.getStringInput("Enter Store Name: ");
                    String storeAddress = inputHandler.getStringInput("Enter Store Address: ");
                    deliveryService.addStore(storeId, storeName, storeAddress);
                    break;
                case 2: // Add Delivery Person
                    String personId = inputHandler.getStringInput("Enter Delivery Person ID: ");
                    String personName = inputHandler.getStringInput("Enter Delivery Person Name: ");
                    String contactNum = inputHandler.getStringInput("Enter Contact Number: ");
                    deliveryService.addDeliveryPerson(personId, personName, contactNum);
                    break;
                case 3: // Add Package
                    String trackingId = inputHandler.getStringInput("Enter Package Tracking ID: ");
                    String sender = inputHandler.getStringInput("Enter Sender Name: ");
                    String recipient = inputHandler.getStringInput("Enter Recipient Name: ");
                    String destination = inputHandler.getStringInput("Enter Destination Address: ");
                    String associatedStoreId = inputHandler.getStringInput("Enter Associated Store ID: ");
                    deliveryService.addPackage(trackingId, sender, recipient, destination, associatedStoreId);
                    break;
                case 4: // Assign Package to Delivery Person
                    String assignTrackingId = inputHandler.getStringInput("Enter Package Tracking ID to assign: ");
                    String assignPersonId = inputHandler.getStringInput("Enter Delivery Person ID: ");
                    deliveryService.assignPackage(assignTrackingId, assignPersonId);
                    break;
                case 5: // Update Package Status
                    String statusTrackingId = inputHandler.getStringInput("Enter Package Tracking ID to update status: ");
                    String newStatus = inputHandler.getStringInput("Enter New Status (PENDING, IN_TRANSIT, DELIVERED, CANCELED): ");
                    deliveryService.updatePackageStatus(statusTrackingId, newStatus);
                    break;
                case 6: // Display All Stores
                    deliveryService.displayAllStores();
                    break;
                case 7: // Display All Delivery Persons
                    deliveryService.displayAllDeliveryPersons();
                    break;
                case 8: // Display All Packages
                    deliveryService.displayAllPackages();
                    break;
                case 9: // Display Packages by Status
                    String filterStatus = inputHandler.getStringInput("Enter Status to filter by (PENDING, IN_TRANSIT, DELIVERED, CANCELED): ");
                    deliveryService.displayPackagesByStatus(filterStatus);
                    break;
                case 10: // Display Packages by Delivery Person
                    String filterPersonId = inputHandler.getStringInput("Enter Delivery Person ID to filter by: ");
                    deliveryService.displayPackagesByDeliveryPerson(filterPersonId);
                    break;
                case 11: // Display Packages by Store
                    String filterStoreId = inputHandler.getStringInput("Enter Store ID to filter by: ");
                    deliveryService.displayPackagesByStore(filterStoreId);
                    break;
                case 12: // Search Package by Tracking ID
                    String searchTrackingId = inputHandler.getStringInput("Enter Package Tracking ID to search: ");
                    deliveryService.searchPackageByTrackingId(searchTrackingId);
                    break;
                case 0:
                    System.out.println("Exiting Package Delivery Tracker. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println("\nPress Enter to continue...");
            inputHandler.getStringInput("");
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Delivery Tracker Menu ---");
        System.out.println("1. Add New Store");
        System.out.println("2. Add New Delivery Person");
        System.out.println("3. Add New Package");
        System.out.println("4. Assign Package to Delivery Person");
        System.out.println("5. Update Package Status");
        System.out.println("6. Display All Stores");
        System.out.println("7. Display All Delivery Persons");
        System.out.println("8. Display All Packages");
        System.out.println("9. Display Packages by Status");
        System.out.println("10. Display Packages by Delivery Person");
        System.out.println("11. Display Packages by Store");
        System.out.println("12. Search Package by Tracking ID");
        System.out.println("0. Exit");
        System.out.println("-----------------------------");
    }
}