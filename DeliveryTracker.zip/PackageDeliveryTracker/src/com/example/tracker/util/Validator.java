package com.example.tracker.util;

public class Validator {

    public static boolean isNotNullOrEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }

    public static boolean isValidContactNumber(String contact) {
        if (!isNotNullOrEmpty(contact)) {
            return false;
        }
        // Simple validation: 10-15 digits, optional hyphens or spaces
        return contact.matches("^[0-9\\-\\s]{10,15}$");
    }

    public static boolean isValidTrackingId(String trackingId) {
        if (!isNotNullOrEmpty(trackingId)) {
            return false;
        }
        // Simple validation: alphanumeric, 6 to 10 characters
        return trackingId.matches("^[a-zA-Z0-9]{6,10}$");
    }
}