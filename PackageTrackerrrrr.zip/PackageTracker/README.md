# Package Delivery Tracker for Local Stores

## Overview
This is a simple Java Swing application designed to help local stores manage and track package deliveries. It provides a user-friendly graphical interface (GUI) to add new packages, update their delivery status, track individual packages by ID, and view a list of all current packages.

## Features
* **Add Package:** Easily input sender, recipient, and address details for new packages.
* **Update Status:** Change the status of a package (e.g., Pending, Dispatched, In Transit, Delivered) using its unique ID.
* **Track Package:** Look up the details and current status of any package using its ID.
* **View All Packages:** See a comprehensive list of all packages currently being tracked, along with their details and status.
* **Unique Package IDs:** Each package is assigned a unique ID for easy tracking.

---

## How to Run the Application

### Prerequisites
* Java Development Kit (JDK) 8 or higher installed on your system.

### Steps
1.  **Save the Code:** Save the provided Java code into a file named `PackageDeliveryTrackerGUI.java` in a directory of your choice (e.g., `C:\Projects\PackageTracker`).

2.  **Compile the Code:**
    Open your terminal or command prompt, navigate to the directory where you saved the file, and compile the Java code:
    ```bash
    javac PackageDeliveryTrackerGUI.java
    ```

3.  **Run the Application:**
    After successful compilation, run the application from the same terminal:
    ```bash
    java PackageDeliveryTrackerGUI
    ```

A GUI window titled "Package Delivery Tracker for Local Stores" will appear, allowing you to interact with the system.

---

## Project Structure
The project is contained within a single Java file, `PackageDeliveryTrackerGUI.java`, which includes three main classes:
* `PackageDeliveryTrackerGUI`: The main class responsible for the Swing GUI and handling user interactions.
* `Package`: An inner static class representing a single package with properties like ID, sender, recipient, address, and status.
* `DeliveryTracker`: An inner static class that manages the collection of `Package` objects and provides methods for adding, updating, and retrieving packages.

---

## Future Enhancements (Ideas)
* Persistence: Save package data to a file or database so it's not lost when the application closes.
* Search functionality by sender/recipient name.
* Sorting and filtering options for viewing packages.
* More detailed tracking information (e.g., timestamps for status changes).
* Integration with external APIs for real-time tracking (if applicable).